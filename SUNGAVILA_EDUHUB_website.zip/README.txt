SUNGAVILA EDUHUB — Starter Website

FILES
- index.html: website content and sections
- style.css: light-blue + white responsive design
- script.js: mobile navigation and category search

HOW TO PREVIEW
Open index.html in a browser, or upload all three files together to a static hosting service.

IMPORTANT
This is a starter front-end website. It does not yet contain real past-paper PDFs or a database. Add your own resource links/files before sharing it with students. Confirm that each uploaded resource is permitted to be shared and matches the Sri Lankan syllabus. The A/L section includes the five broad stream categories requested; exact subject combinations should be checked against the current official syllabus.

FREE HOSTING OPTIONS
- Netlify: https://www.netlify.com/
- Cloudflare Pages: https://pages.cloudflare.com/

Keep index.html, style.css, and script.js in the same folder.
